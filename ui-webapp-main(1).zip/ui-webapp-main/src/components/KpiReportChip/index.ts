export { default } from './KpiChip2';

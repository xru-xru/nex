export { default } from './KPIsCompareSidePanel';

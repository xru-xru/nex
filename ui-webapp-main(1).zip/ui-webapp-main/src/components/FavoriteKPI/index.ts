export { default } from './FavoriteKPI';

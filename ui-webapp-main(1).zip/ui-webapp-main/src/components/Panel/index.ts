export { default } from './Panel';

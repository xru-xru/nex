export { default } from './ErrorBoundary';

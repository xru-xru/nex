export const classes = {
  root: 'NEXYListItem',
  disabled: 'disabled',
  selected: 'selected',
};

export { default } from './MultipleSwitch';

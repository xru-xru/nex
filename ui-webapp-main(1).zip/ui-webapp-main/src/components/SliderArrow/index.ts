export { default } from './SliderArrow';

export { default } from './KpiPill';

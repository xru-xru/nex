export { default } from './Fade';

export const classes = {
  search: {
    root: 'NEXYsearch',
  },
};

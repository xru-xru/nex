export { default } from './KPIsSelectedSlider';

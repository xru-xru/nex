export { default } from './AvatarReport';

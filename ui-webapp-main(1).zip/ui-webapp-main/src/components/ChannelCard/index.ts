export { default } from './ChannelCard';

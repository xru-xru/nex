export { default as Desktop } from './Desktop';
export { default as Tablet } from './Tablet';
export { default as Laptop } from './Laptop';
export { default as LaptopL } from './LaptopL';
export { default as LaptopLUp } from './LaptopLUp';

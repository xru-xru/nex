export { default } from './FormattedCurrency';

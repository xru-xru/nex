export { default } from './LoadingPlaceholder';

export { default } from './InputLabel';

export { default } from './FormControlLabel';

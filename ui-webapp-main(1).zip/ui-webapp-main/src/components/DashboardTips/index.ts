export { default } from './DashboardTips';

export { default as ContentTable } from './ContentTable';

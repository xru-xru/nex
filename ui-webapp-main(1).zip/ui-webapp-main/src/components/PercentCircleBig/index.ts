export { default } from './PercentCircleBig';

export const classes = {
  root: 'NEXYListItemIcon',
};

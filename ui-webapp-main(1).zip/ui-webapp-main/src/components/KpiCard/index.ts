export { default } from './KpiCard';

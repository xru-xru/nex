// @fow
export const classes = {
  root: 'NEXYMainContent',
};

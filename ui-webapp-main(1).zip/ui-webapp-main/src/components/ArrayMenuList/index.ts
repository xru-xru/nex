export { default } from './ArrayMenuList';

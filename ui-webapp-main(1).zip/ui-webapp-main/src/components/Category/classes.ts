export const classes = {
  root: 'NEXYCategory',
  social: 'NEXYsocial',
  mailing: 'NEXYmailing',
  video: 'NEXYvideo',
  search: 'NEXYsearch',
  website: 'NEXYwebsite',
  mobile: 'NEXYmobile',
  ad: 'NEXYad',
};

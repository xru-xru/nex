module.exports = {
  extends: 'semantic-release-config-nexoya',
};

// This file is intentionally empty to remove pdfmake from the bundle as it's not needed and huge
export default {};

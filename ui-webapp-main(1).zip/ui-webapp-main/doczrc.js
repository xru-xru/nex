export default {
  title: 'Nexoya',
  description: 'Intelligent KPIs in Digital Marketing',
  themeConfig: {
    colors: {
      primary: '#10A7EE',
    },
  },
};

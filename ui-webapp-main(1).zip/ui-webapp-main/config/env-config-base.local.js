// Base configuration shared across all hosts
window.nexyBaseConfig = {
  REACT_APP_VERSION: 'SETME',
  REACT_APP_AMCHARTS_KEY: 'CH224918621',
  REACT_APP_AMPLITUDE_KEY: '0a27836edc9241d48c5b43b1e3a3fd2f',
  REACT_APP_DEV_HELPER: 'true',
  REACT_APP_DATADOG_APP_ID: '',
  REACT_APP_DATADOG_CLIENT_TOKEN: '',
};
